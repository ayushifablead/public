import React, { useState } from "react";
import Breadcrumb from "../common/breadcrumb";
import { roleModel } from "../../constant";


const MyLifeMenifesto = () => {
  const [formData, setFormData] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation here before submitting
    // Example: Check if required fields are filled
    // if (formData.winning === "" || formData.why === "" || ...) {
    //   alert("Please fill in all required fields.");
    //   return;
    // }
    console.log(formData); // For testing, you can remove this later
    // Submit form data to backend or perform other actions
  };


  return (
    <div>
      <Breadcrumb parent="My Future" title="My Life Manifesto" />
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card">
             
              <form className="form theme-form" onSubmit={handleSubmit}>
                <div className="card-body m-3">
                  <div className="row">
                    <div className="col-sm-12">
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Here`s What I know For sure</label>
                        <input
                          className="form-control"
                          name="think"
                          required
                        />
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Believe That</label>
                        <input type="text" className="form-control" name="Believe" required />
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Want To Live In A World</label>
                        <input type="text" className="form-control" name="Live" required />
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Embrace</label>
                        <input type="text" className="form-control" name="Embrace" required />
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Want To Nothing More Then</label>
                        <input type="text" className="form-control" name="Nothing" required />
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Care Deeply About</label>
                        <input type="text" className="form-control" name="Deeply" required />
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Believe That</label>
                        <input type="text" className="form-control" name="Believe" required />
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Want tO Live  In A World</label>
                        <input type="text" className="form-control" name="Want" required />
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Hear`s` What I Know For Sure</label>
                        <input type="text" className="form-control" name="Sure" required />
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Hope To One Day</label>
                        <input type="text" className="form-control" name="Hope" required />
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Feed Off</label>
                        <input type="text" className="form-control" name="Feed" required />
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Will Be Responsible For</label>
                        <input type="text" className="form-control" name="Will" required />
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Will Show The World That </label>
                        <input type="text" className="form-control" name="Show" required />
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">My Passion</label>
                        <input type="text" className="form-control" name="Passion" required />
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Am Fanatical About</label>
                        <input type="text" className="form-control" name="Fanatical" required />
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Strive To</label>
                        <input type="text" className="form-control" name="Strive" required />
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">I Am </label>
                        <input type="text" className="form-control" name="Am" required />
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Because I</label>
                        <input type="text" className="form-control" name="Because" required />
                      </div>


                      <div className="card-footer">
                        <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                      </div>

                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

}

export default MyLifeMenifesto;
