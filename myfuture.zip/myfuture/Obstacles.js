import React, { useState } from "react";
import Breadcrumb from "../common/breadcrumb";
import { obstacles } from "../../constant";


const Obstacles = () => {
  const [formData, setFormData] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation here before submitting
    // Example: Check if required fields are filled
    // if (formData.winning === "" || formData.why === "" || ...) {
    //   alert("Please fill in all required fields.");
    //   return;
    // }
    console.log(formData); // For testing, you can remove this later
    // Submit form data to backend or perform other actions
  };


  return (
    <div>
      <Breadcrumb parent="My Future" title="obstacles" />
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card">
            
              <form className="form theme-form" onSubmit={handleSubmit}>
                <div className="card-body m-3">
                  <div className="row">
                    <div className="col-sm-12">
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Name Three People Who Have A Broken Relationship With </label>
                        <textarea
                          className="form-control"
                          name="winning"
                          rows="4"
                          required
                        ></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">What is the one goal that you are most passionate about right now in your life?</label>
                        <textarea className="form-control" rows="4" name="goal" required ></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Write a one-sentence telegram reminding yourself why you are so passionate about this goal.</label>
                        <textarea className="form-control" rows="4" name="telegram" required></textarea>
                      </div>


                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">What Was Your obstacles and how will you overcome them in achieving your goal?</label>
                        <textarea className="form-control" rows="4" name="obstacles" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">what and/or who will help you reach your goal(family/friends/network;strengths,skills,knowledge,money,attitude,etc.)?</label>
                        <textarea className="form-control" rows="4" name="help" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">what more do you need(e.g.experience,learning,resources)?what whould be most helpful?Be as specific as you can.</label>
                        <textarea className="form-control" rows="4" name="need" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">How will you celebrate?</label>
                        <textarea className="form-control" rows="4" name="celebrate" required ></textarea>
                      </div>

                      <div className="card-footer">
                        <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                      </div>

                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

}

export default Obstacles;
