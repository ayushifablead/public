import React, { useState } from "react";
import Breadcrumb from "../common/breadcrumb";
import { MarginBottom, roleModel } from "../../constant";
import '../../assets/css/style1.css';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import Modal from 'react-bootstrap/Modal';
import {Table ,Container , Row ,Col} from 'react-bootstrap';
import { FaRegEdit } from "react-icons/fa";
import { MdDelete } from "react-icons/md";

const RoleModel = () => {
  const [formData, setFormData] = useState({});
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation here before submitting
    // Example: Check if required fields are filled
    // if (formData.winning === "" || formData.why === "" || ...) {
    //   alert("Please fill in all required fields.");
    //   return;
    // }
    console.log(formData); // For testing, you can remove this later
    // Submit form data to backend or perform other actions
  };


  return (
  
    <>
    <Container>
    {/* <Breadcrumb parent="My Future" title="Role Models" /> */}
      <Row>
        <Col sm={4}></Col>
        <Col sm={4}></Col>
        <Col sm={4}>
    
        <Button variant="primary" onClick={handleShow} style={{ marginBottom: '20px', float:'right'}}>
  Add New Role
</Button>

      </Col>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Role Models</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Name Of Person Admiration </Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Name Of Person Admiration"
                autoFocus
                required
                className="Admiration"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Life Area </Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Life Area"
                autoFocus
                required
                className="Life"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Why ?</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Why ?"
                autoFocus
                required
                name="why"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Thing I Think I Can Learn</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Thing I Think I Can Learn"
                autoFocus
                required
                name="Thing"
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Action to Initiate this Learning</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Why ?"
                autoFocus
                required
                name="why"
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleClose}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
      </Row>
      <Row>
      <div className="row">
          <div className="col-sm-12">
            <div className="card">
              <div className="card-header">
                <h5>Role Modals</h5>
              </div>
              <div className="card-body">
                <Table striped bordered hover>
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Life Area</th>
                      <th>Why ?</th>
                      <th>Thing I Think I Can Learn</th>
                      <th>Action to Initiate this Learning</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                   
                      <tr>
                        <td>abc</td>
                        <td>Financial</td>
                        <td>abc</td>
                        <td>abc</td>
                        <td>abc</td>
                        <td>
                      <Button className="btn-primary btn-pill edit-buttons mx-2" ><FaRegEdit /></Button>
                          <Button variant="danger" className=" btn-primary btn-pill edit-buttons" ><MdDelete /></Button>
                        </td>
                      </tr>
                  
                  </tbody>
                </Table>
              </div>
            </div>
          </div>
        </div>
        </Row>
        </Container>
    </>
    
  );

}

export default RoleModel;
