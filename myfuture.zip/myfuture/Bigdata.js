import React, { useState } from "react";
import Breadcrumb from "../common/breadcrumb";
import { bigdata } from "../../constant";


const Bigdata = () => {
  const [formData, setFormData] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation here before submitting
    // Example: Check if required fields are filled
    // if (formData.winning === "" || formData.why === "" || ...) {
    //   alert("Please fill in all required fields.");
    //   return;
    // }
    console.log(formData); // For testing, you can remove this later
    // Submit form data to backend or perform other actions
  };


  return (
    <div>
      <Breadcrumb parent="My Future" title="My Very Big Dream" />
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card">
             
              <form className="form theme-form" onSubmit={handleSubmit}>
                <div className="card-body m-3">
                  <div className="row">
                    <div className="col-sm-12">
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">For the fun of it,think now of once or two big ,hariy,audacious goals you might want to pursue now or sometime later in your life .these would be considered your personal moon shots of something you would love to do achieve or accomplish in your lifeline .brainstorm and writethem down here </label>
                        <textarea
                          className="form-control"
                          name="winning"
                          rows="4"
                          required
                        ></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">how important is this dream to you?</label>
                        <textarea className="form-control" rows="4" name="dream" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">how benefical would your dream be to your family, friends and to your legacy?</label>
                        <textarea className="form-control" rows="4" name="benefical" required></textarea>
                      </div>


                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">how benefical would your dream be to society as whole?</label>
                        <textarea className="form-control" rows="4" name="your" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">How pleasurable versus painful would your dream be to society as a whole?</label>
                        <textarea className="form-control" rows="4" name="pleasurable" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">How likely are you to achieve this dream in your lifetime ? </label>
                        <textarea className="form-control" rows="4" name="likely" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">if you fail ,how big a price would you pay to try ? for example ,would you likely lose your job ? and how bad would that lose or cost be for you to try ?</label>
                        <textarea className="form-control" rows="4" name="fail" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">what`s the worst outcome that realistically could happen if you try and don`t succeed?</label>
                        <textarea className="form-control" rows="4" name="worst" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Is there a way to reduce the risk while still allowing for lots of benefit by going for your big goal and dream ?</label>
                        <textarea className="form-control" rows="4" name="reduce" required></textarea>
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">my very big dream aka myLife`s north star aka my personal moon short is:</label>
                        <textarea className="form-control" rows="4" name="dream" required></textarea>
                      </div>
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">my top 5 Life Goals I need from my big dream Are </label>
                        <input type="text" className="form-control" name="Life" required />
                      </div>

                      <div className="card-footer">
                        <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                      </div>

                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

}

export default Bigdata;
