import React, { useState } from "react";
import Breadcrumb from "../common/breadcrumb";
import { roleModel } from "../../constant";


const VisionBoard = () => {
  const [formData, setFormData] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation here before submitting
    // Example: Check if required fields are filled
    // if (formData.winning === "" || formData.why === "" || ...) {
    //   alert("Please fill in all required fields.");
    //   return;
    // }
    console.log(formData); // For testing, you can remove this later
    // Submit form data to backend or perform other actions
  };


  return (
    <div>
      <Breadcrumb parent="My Future" title="My Vision Board" />
    
    </div>
  );

}

export default VisionBoard;
