import React, { useState } from "react";
import Breadcrumb from "../common/breadcrumb";
import { roleModel } from "../../constant";
import Button from 'react-bootstrap/Button';
import {  Modal, Table } from 'react-bootstrap';
import { FaRegEdit } from 'react-icons/fa';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import { MdDelete } from 'react-icons/md';
const LifeGoal = () => {
  const [formData, setFormData] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [gratitudeEntries, setGratitudeEntries] = useState([]);
const [gratitudeDetails, setGratitudeDetails] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setGratitudeDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value
    }));
  };

  
  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation here before submitting
    // Example: Check if required fields are filled
    // if (formData.winning === "" || formData.why === "" || ...) {
    //   alert("Please fill in all required fields.");
    //   return;
    // }
    console.log(formData); // For testing, you can remove this later
    // Submit form data to backend or perform other actions
  };

  const toggleModal = () => {
    setShowModal(!showModal);
  };
  const handleSave = () => {
    setGratitudeEntries([...gratitudeEntries, gratitudeDetails]);
    toggleModal();
  };

  return (
    <div>
      <Breadcrumb parent="My Future" title="Life Goals" />
      <div className='mb-4 d-flex justify-content-end'>
          <Button onClick={toggleModal}>Add Goal</Button>
        </div>
        <Modal show={showModal} onHide={toggleModal} className=''>
          <Modal.Header closeButton>
            <Modal.Title>Add Daily affirmation</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="form-group">
              <label>Item</label>
              <input type="text" className="form-control" name="item" onChange={handleInputChange} />
            </div>
            <div className="form-group mt-3">
              <label>Assigned To</label>
              <textarea className="form-control" rows="4" name="gratitude" onChange={handleInputChange} />
            </div>

            <div className="form-group mt-3">
              <label>Priority</label>
              <textarea className="form-control" rows="4" name="reason" onChange={handleInputChange} />
            </div>
            <div className="form-group">
              <label>Due Date</label>
              <DatePicker
             
                dateFormat="dd/MM/yyyy"
                className="form-control"
                name="date"
              />
            </div>
            <div className="form-group mt-3">
              <label>Status</label>
              <textarea className="form-control" rows="4" name="reason" onChange={handleInputChange} />
            </div>
            <div className="form-group mt-3">
              <label>Type</label>
              <textarea className="form-control" rows="4" name="reason" onChange={handleInputChange} />
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={toggleModal}>Close</Button>
            <Button variant="primary" onClick={handleSave}>Save</Button>
          </Modal.Footer>
        </Modal>
        
        <div className="row">
          <div className="col-sm-12">
            <div className="card">
              <div className="card-header">
                <h5>Life Goals</h5>
              </div>
              <div className="card-body">
                <Table striped bordered hover>
                  <thead>
                    <tr>
                      <th>Item</th>
                      <th>Assigned To</th>
                      <th>Priority</th>
                      <th>Due Date</th>
                      <th>Status</th>
                      <th>Type</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                   
                      <tr>
                        <td>$2.5 Booked in Revenue</td>
                        <td><img src="https://static-00.iconduck.com/assets.00/profile-default-icon-2048x2045-u3j7s5nj.png" width={30} height={30}></img></td>
                        <td></td>
                        <td>20/5/2023</td>
                        <td>Pending</td>
                        <td>this quarter</td>
                        <td>
                      <Button className="btn-primary btn-pill edit-buttons mx-2" ><FaRegEdit /></Button>
                          <Button variant="danger" className=" btn-primary btn-pill edit-buttons" ><MdDelete /></Button>
                        </td>
                      </tr>
                       
                      <tr>
                        <td>$2.5 Booked in Revenue</td>
                        <td><img src="https://static-00.iconduck.com/assets.00/profile-default-icon-2048x2045-u3j7s5nj.png" width={30} height={30}></img></td>
                        <td></td>
                        <td>20/5/2023</td>
                        <td>Pending</td>
                        <td>this quarter</td>
                        <td>
                      <Button className="btn-primary btn-pill edit-buttons mx-2" ><FaRegEdit /></Button>
                          <Button variant="danger" className=" btn-primary btn-pill edit-buttons" ><MdDelete /></Button>
                        </td>
                      </tr>
                  
                  </tbody>
                </Table>
              </div>
            </div>
          </div>
        </div>

    </div>
  );

}

export default LifeGoal;
