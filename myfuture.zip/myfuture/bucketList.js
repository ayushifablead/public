import React, { useState } from "react";
import Breadcrumb from "../common/breadcrumb";
import { roleModel } from "../../constant";
import Button from 'react-bootstrap/Button';
import {  Modal, Table } from 'react-bootstrap';
import { FaRegEdit } from 'react-icons/fa';
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

const BucketList = () => {
  const [formData, setFormData] = useState({});
  const [showModal, setShowModal] = useState(false);
  const [gratitudeEntries, setGratitudeEntries] = useState([]);
const [gratitudeDetails, setGratitudeDetails] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setGratitudeDetails((prevDetails) => ({
      ...prevDetails,
      [name]: value
    }));
  };

  
  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation here before submitting
    // Example: Check if required fields are filled
    // if (formData.winning === "" || formData.why === "" || ...) {
    //   alert("Please fill in all required fields.");
    //   return;
    // }
    console.log(formData); // For testing, you can remove this later
    // Submit form data to backend or perform other actions
  };

  const toggleModal = () => {
    setShowModal(!showModal);
  };
  const handleSave = () => {
    setGratitudeEntries([...gratitudeEntries, gratitudeDetails]);
    toggleModal();
  };



  


  return (
    <div>
      <Breadcrumb parent="My Future" title="My Bucket List" />
    
 
        <Modal show={showModal} onHide={toggleModal} className=''>
          <Modal.Header closeButton>
            <Modal.Title>My Bucket List</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div className="form-group">
              <label>Uniq Bucket List</label>
              <input type="text" className="form-control" name="item" onChange={handleInputChange} />
            </div>
          
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={toggleModal}>Close</Button>
            <Button variant="primary" onClick={handleSave}>Save</Button>
          </Modal.Footer>
        </Modal>
        <div className="col-sm-12">
                        <div className="card">
                            <div className="card-header ">
                                <div className="row">
                                    <div className="col-md-6 align-content-end">
                                        <h5 >Travel</h5>
                                    </div>
                                    <div className="col-md-6 text-end">
                                        <button className="btn btn-primary" onClick={toggleModal}>Add Bucket List</button>
                                    </div>
                                </div>
                            </div>
                            <form className="form theme-form" onSubmit={handleSubmit}>
                                <div className="card-body m-2">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani">
                                                <input className="checkbox_animated" id="chk-ani" type="checkbox" />
                                                {Option} {"See The Northern Lights"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani1">
                                                <input className="checkbox_animated" id="chk-ani1" type="checkbox" />
                                                {Option} {"Live Abroad"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani2">
                                                <input className="checkbox_animated" id="chk-ani2" type="checkbox" />
                                                {Option} {"Travel The Coast"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani3">
                                                <input className="checkbox_animated" id="chk-ani3" type="checkbox" />
                                                {Option} {"Fly First Class"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani4">
                                                <input className="checkbox_animated" id="chk-ani4" type="checkbox" />
                                                {Option} {"Go On A Safari"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani5">
                                                <input className="checkbox_animated" id="chk-ani5" type="checkbox" />
                                                {Option} {"Go On A Walking Holiday"}
                                            </label>
                                        </div>

                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani6">
                                                <input className="checkbox_animated" id="chk-ani6" type="checkbox" />
                                                {Option} {"Go On A Backpacking Holday"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani7">
                                                <input className="checkbox_animated" id="chk-ani7" type="checkbox" />
                                                {Option} {"Hire A canal Boat"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani8">
                                                <input className="checkbox_animated" id="chk-ani8" type="checkbox" />
                                                {Option} {"Act Like A Tourist In Your Own Town"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani9">
                                                <input className="checkbox_animated" id="chk-ani9" type="checkbox" />
                                                {Option} {"Go On A Road Trip"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani10">
                                                <input className="checkbox_animated" id="chk-ani10" type="checkbox" />
                                                {Option} {"Go Camping"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani11">
                                                <input className="checkbox_animated" id="chk-ani11" type="checkbox" />
                                                {Option} {"Visit Stonehenge"}
                                            </label>
                                        </div>

                                      

                                        <div className="card-footer">
                                            <button type="submit" className="btn btn-primary me-1 float-end" >Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div className="card">
                            <div className="card-header ">
                                <div className="row">
                                    <div className="col-md-6 align-content-end">
                                        <h5 >Learn</h5>
                                    </div>
                                    <div className="col-md-6 text-end">
                                        <button className="btn btn-primary" onClick={toggleModal}>Add Bucket List</button>
                                    </div>
                                </div>
                            </div>
                            <form className="form theme-form" onSubmit={handleSubmit}>
                                <div className="card-body m-2">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani">
                                                <input className="checkbox_animated" id="chk-ani" type="checkbox" />
                                                {Option} {"Learn How To play An Instrument"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani1">
                                                <input className="checkbox_animated" id="chk-ani1" type="checkbox" />
                                                {Option} {"Study For A degree"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani2">
                                                <input className="checkbox_animated" id="chk-ani2" type="checkbox" />
                                                {Option} {"Learn A New Language"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani3">
                                                <input className="checkbox_animated" id="chk-ani3" type="checkbox" />
                                                {Option} {"Learn A New Style Of Dance"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani4">
                                                <input className="checkbox_animated" id="chk-ani4" type="checkbox" />
                                                {Option} {"Learn How To Draw/Paint"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani5">
                                                <input className="checkbox_animated" id="chk-ani5" type="checkbox" />
                                                {Option} {"Learn How To Back From Scratch"}
                                            </label>
                                        </div>

                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani6">
                                                <input className="checkbox_animated" id="chk-ani6" type="checkbox" />
                                                {Option} {"Learn How To Solve A Rubik`s Cude"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani7">
                                                <input className="checkbox_animated" id="chk-ani7" type="checkbox" />
                                                {Option} {"Learn Basic First Aid"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani8">
                                                <input className="checkbox_animated" id="chk-ani8" type="checkbox" />
                                                {Option} {"Learn How To Tie knots"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani9">
                                                <input className="checkbox_animated" id="chk-ani9" type="checkbox" />
                                                {Option} {"Learn How To Tie Knots"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani10">
                                                <input className="checkbox_animated" id="chk-ani10" type="checkbox" />
                                                {Option} {"Learn How To Fish"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani11">
                                                <input className="checkbox_animated" id="chk-ani11" type="checkbox" />
                                                {Option} {"Learn How To Swim"}
                                            </label>
                                        </div>

                                      

                                        <div className="card-footer">
                                            <button type="submit" className="btn btn-primary me-1 float-end" >Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div className="card">
                            <div className="card-header ">
                                <div className="row">
                                    <div className="col-md-6 align-content-end">
                                        <h5 >Revisit The Past</h5>
                                    </div>
                                    <div className="col-md-6 text-end">
                                        <button className="btn btn-primary" onClick={toggleModal}>Add Bucket List</button>
                                    </div>
                                </div>
                            </div>
                            <form className="form theme-form" onSubmit={handleSubmit}>
                                <div className="card-body m-2">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani">
                                                <input className="checkbox_animated" id="chk-ani" type="checkbox" />
                                                {Option} {"Lookup An Old Friend"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani1">
                                                <input className="checkbox_animated" id="chk-ani1" type="checkbox" />
                                                {Option} {"Research Your Family History"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani2">
                                                <input className="checkbox_animated" id="chk-ani2" type="checkbox" />
                                                {Option} {"Create A family Tree"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani3">
                                                <input className="checkbox_animated" id="chk-ani3" type="checkbox" />
                                                {Option} {"Give An Hriloom To SomeOne You Love"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani4">
                                                <input className="checkbox_animated" id="chk-ani4" type="checkbox" />
                                                {Option} {"Visit Where Your Parente Grew Up"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani5">
                                                <input className="checkbox_animated" id="chk-ani5" type="checkbox" />
                                                {Option} {"Write A Journal Of Your Memories"}
                                            </label>
                                        </div>

                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani6">
                                                <input className="checkbox_animated" id="chk-ani6" type="checkbox" />
                                                {Option} {"Revisit Your Honeymoon Destination"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani7">
                                                <input className="checkbox_animated" id="chk-ani7" type="checkbox" />
                                                {Option} {"Attend A School Reunion"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani8">
                                                <input className="checkbox_animated" id="chk-ani8" type="checkbox" />
                                                {Option} {"Learn ThE History Of Place You Love"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani9">
                                                <input className="checkbox_animated" id="chk-ani9" type="checkbox" />
                                                {Option} {"Create A scrapbook or Your Children"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani10">
                                                <input className="checkbox_animated" id="chk-ani10" type="checkbox" />
                                                {Option} {"Visit Location From Your Childhood"}
                                            </label>
                                           
                                        </div>

                                      

                                        <div className="card-footer">
                                            <button type="submit" className="btn btn-primary me-1 float-end" >Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div className="card">
                            <div className="card-header ">
                                <div className="row">
                                    <div className="col-md-6 align-content-end">
                                        <h5 >Achieve A Life Event</h5>
                                    </div>
                                    <div className="col-md-6 text-end">
                                        <button className="btn btn-primary" onClick={toggleModal}>Add Bucket List</button>
                                    </div>
                                </div>
                            </div>
                            <form className="form theme-form" onSubmit={handleSubmit}>
                                <div className="card-body m-2">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani">
                                                <input className="checkbox_animated" id="chk-ani" type="checkbox" />
                                                {Option} {"Buy A House"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani1">
                                                <input className="checkbox_animated" id="chk-ani1" type="checkbox" />
                                                {Option} {"Conquer A fear"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani2">
                                                <input className="checkbox_animated" id="chk-ani2" type="checkbox" />
                                                {Option} {"Fall In Love"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani3">
                                                <input className="checkbox_animated" id="chk-ani3" type="checkbox" />
                                                {Option} {"Get Married"}
                                            </label>

                                       
                                        </div>

                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani6">
                                                <input className="checkbox_animated" id="chk-ani6" type="checkbox" />
                                                {Option} {"Retrie"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani7">
                                                <input className="checkbox_animated" id="chk-ani7" type="checkbox" />
                                                {Option} {"Learn To Drive"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani8">
                                                <input className="checkbox_animated" id="chk-ani8" type="checkbox" />
                                                {Option} {"Adopt A pet"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani9">
                                                <input className="checkbox_animated" id="chk-ani9" type="checkbox" />
                                                {Option} {"Throw Yourself A milestone Party"}
                                            </label>
                                          
                                        </div>

                                      

                                        <div className="card-footer">
                                            <button type="submit" className="btn btn-primary me-1 float-end" >Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div className="card">
                            <div className="card-header ">
                                <div className="row">
                                    <div className="col-md-6 align-content-end">
                                        <h5 >Do Something Daring</h5>
                                    </div>
                                    <div className="col-md-6 text-end">
                                        <button className="btn btn-primary" onClick={toggleModal}>Add Bucket List</button>
                                    </div>
                                </div>
                            </div>
                            <form className="form theme-form" onSubmit={handleSubmit}>
                                <div className="card-body m-2">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani">
                                                <input className="checkbox_animated" id="chk-ani" type="checkbox" />
                                                {Option} {"Go Skinny Dipping"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani1">
                                                <input className="checkbox_animated" id="chk-ani1" type="checkbox" />
                                                {Option} {"Change Your Hair Color"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani2">
                                                <input className="checkbox_animated" id="chk-ani2" type="checkbox" />
                                                {Option} {"Set A Guinness world record"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani3">
                                                <input className="checkbox_animated" id="chk-ani3" type="checkbox" />
                                                {Option} {"Send A message In Bottle"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani4">
                                                <input className="checkbox_animated" id="chk-ani4" type="checkbox" />
                                                {Option} {"Go To A Casino"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani5">
                                                <input className="checkbox_animated" id="chk-ani5" type="checkbox" />
                                                {Option} {"Try Acupuncture"}
                                            </label>
                                        </div>

                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani6">
                                                <input className="checkbox_animated" id="chk-ani6" type="checkbox" />
                                                {Option} {"Revisit Your Honeymoon Destination"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani7">
                                                <input className="checkbox_animated" id="chk-ani7" type="checkbox" />
                                                {Option} {"Attend A School Reunion"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani8">
                                                <input className="checkbox_animated" id="chk-ani8" type="checkbox" />
                                                {Option} {"Learn ThE History Of Place You Love"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani9">
                                                <input className="checkbox_animated" id="chk-ani9" type="checkbox" />
                                                {Option} {"Create A scrapbook or Your Children"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani10">
                                                <input className="checkbox_animated" id="chk-ani10" type="checkbox" />
                                                {Option} {"Visit Location From Your Childhood"}
                                            </label>
                                           
                                        </div>

                                      

                                        <div className="card-footer">
                                            <button type="submit" className="btn btn-primary me-1 float-end" >Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div className="card">
                            <div className="card-header ">
                                <div className="row">
                                    <div className="col-md-6 align-content-end">
                                        <h5 >Do Something You Just Haven`t Got Arounf To</h5>
                                    </div>
                                    <div className="col-md-6 text-end">
                                        <button className="btn btn-primary" onClick={toggleModal}>Add Bucket List</button>
                                    </div>
                                </div>
                            </div>
                            <form className="form theme-form" onSubmit={handleSubmit}>
                                <div className="card-body m-2">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani">
                                                <input className="checkbox_animated" id="chk-ani" type="checkbox" />
                                                {Option} {" Start a business"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani1">
                                                <input className="checkbox_animated" id="chk-ani1" type="checkbox" />
                                                {Option} {"Start a business"}

                                            </label>

                                            <label className="d-block" htmlFor="chk-ani2">
                                                <input className="checkbox_animated" id="chk-ani2" type="checkbox" />
                                                {Option} {"Write a book"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani3">
                                                <input className="checkbox_animated" id="chk-ani3" type="checkbox" />
                                                {Option} {"Build something from scratch"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani4">
                                                <input className="checkbox_animated" id="chk-ani4" type="checkbox" />
                                                {Option} {"Decorate your home"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani5">
                                                <input className="checkbox_animated" id="chk-ani5" type="checkbox" />
                                                {Option} {"Watch that film you've always wanted to"}
                                            </label>
                                        </div>

                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani6">
                                                <input className="checkbox_animated" id="chk-ani6" type="checkbox" />
                                                {Option} {"Revisit Your Honeymoon Destination"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani7">
                                                <input className="checkbox_animated" id="chk-ani7" type="checkbox" />
                                                {Option} {"Attend A School Reunion"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani8">
                                                <input className="checkbox_animated" id="chk-ani8" type="checkbox" />
                                                {Option} {"Learn ThE History Of Place You Love"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani9">
                                                <input className="checkbox_animated" id="chk-ani9" type="checkbox" />
                                                {Option} {"Create A scrapbook or Your Children"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani10">
                                                <input className="checkbox_animated" id="chk-ani10" type="checkbox" />
                                                {Option} {"Visit Location From Your Childhood"}
                                            </label>
                                           
                                        </div>

                                      

                                        <div className="card-footer">
                                            <button type="submit" className="btn btn-primary me-1 float-end" >Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div className="card">
                            <div className="card-header ">
                                <div className="row">
                                    <div className="col-md-6 align-content-end">
                                        <h5 >Do Something for Someone Else









</h5>
                                    </div>
                                    <div className="col-md-6 text-end">
                                        <button className="btn btn-primary" onClick={toggleModal}>Add Bucket List</button>
                                    </div>
                                </div>
                            </div>
                            <form className="form theme-form" onSubmit={handleSubmit}>
                                <div className="card-body m-2">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani">
                                                <input className="checkbox_animated" id="chk-ani" type="checkbox" />
                                                {Option} {"Do a sponsored walk/run"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani1">
                                                <input className="checkbox_animated" id="chk-ani1" type="checkbox" />
                                                {Option} {"Pay for a stranger's drink"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani2">
                                                <input className="checkbox_animated" id="chk-ani2" type="checkbox" />
                                                {Option} {"Volunteer at a community project"}
                                            </label>

                                            <label className="d-block" htmlFor="chk-ani3">
                                                <input className="checkbox_animated" id="chk-ani3" type="checkbox" />
                                                {Option} {"Take your family on a surprise vacation"}
                                            </label>

                                           
                                        </div>

                                        <div className="col-lg-6">
                                            <label className="d-block" htmlFor="chk-ani6">
                                                <input className="checkbox_animated" id="chk-ani6" type="checkbox" />
                                                {Option} {"Say 'yes' to everything for a day"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani4">
                                                <input className="checkbox_animated" id="chk-ani4" type="checkbox" />
                                                {Option} {"Plan a surprise party for a loved one"}
                                            </label>
                                            <label className="d-block" htmlFor="chk-ani5">
                                                <input className="checkbox_animated" id="chk-ani5" type="checkbox" />
                                                {Option} {"Give a stranger a compliment"}
                                            </label>
                                           
                                        </div>

                                      

                                        <div className="card-footer">
                                            <button type="submit" className="btn btn-primary me-1 float-end" >Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
    </div>
  );

}

export default BucketList;
