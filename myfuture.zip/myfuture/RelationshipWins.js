import React, { useState } from "react";
import Breadcrumb from "../common/breadcrumb";
import { relationshipWins } from "../../constant";


const RelationshipWins = () => {
  const [formData, setFormData] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation here before submitting
    // Example: Check if required fields are filled
    // if (formData.winning === "" || formData.why === "" || ...) {
    //   alert("Please fill in all required fields.");
    //   return;
    // }
    console.log(formData); // For testing, you can remove this later
    // Submit form data to backend or perform other actions
  };


  return (
    <div>
      <Breadcrumb parent="My Future" title="Relationship Wins" />
      <div className="container-fluid">
        <div className="row">
          <div className="col-sm-12">
            <div className="card">
           
              <form className="form theme-form" onSubmit={handleSubmit}>
                <div className="card-body m-3">
                  <div className="row">
                    <div className="col-sm-12">
                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Name Three People Who Have A Broken Relationship With </label>
                        <textarea
                          className="form-control"
                          name="winning"
                          rows="4"
                          required
                        ></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Name Of The Person You Want to Foucs on in This Exercise </label>
                        <textarea className="form-control"  name="Person"  rows="4" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Why Is The Relationship Between You and this person Broken ?</label>
                        <textarea className="form-control" name="Relationship" rows="4" required></textarea>
                      </div>


                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">What Was Your Part In The Releationship Drifting Apart?</label>
                        <textarea className="form-control" rows="4" name="Part" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Specifically, What Did You Do or not do,that could have been done differntly to preserve the relationship ?</label>
                        <textarea className="form-control" rows="4" name="Specifically" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">Why is this relationship important to you ?</label>
                        <textarea className="form-control" rows="4" name="important" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">If You Fix The Relationship, What Would That Mean To You ?</label>
                        <textarea className="form-control" rows="4" name="Relationship" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">If You Do Nothing,Don`t Try To Fix The Relationship, What Would That Mean For You?</label>
                        <textarea className="form-control" rows="4" name="Nothing" required></textarea>
                      </div>

                      <div className="form-group row mb-2">
                        <label className="col-sm-12 col-form-label">What Are The Steps That You Are Committing To Do , In Attempt To Apologize For Your Part,In The Relationship Being Estranged?</label>
                        <input type="text" className="form-control" name="Steps" required/>
                      </div>

                      <div className="card-footer">
                        <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                      </div>

                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

}

export default RelationshipWins;
