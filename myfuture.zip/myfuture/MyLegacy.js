import React, { useState } from "react";
import Breadcrumb from "../common/breadcrumb";
import { Container, Nav, NavItem, Tab, TabContent, TabPane, Tabs } from "react-bootstrap";
import { NavLink } from "react-router-dom";

const MyLegacy = () => {
  const [formData, setFormData] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation here before submitting
    // Example: Check if required fields are filled
    // if (formData.winning === "" || formData.why === "" || ...) {
    //   alert("Please fill in all required fields.");
    //   return;
    // }
    console.log(formData); // For testing, you can remove this later
    // Submit form data to backend or perform other actions
  };


  return (
    <div>
      <Breadcrumb parent="My Future" title="MyLegacy" />
      <Container fluid={true}>
        {/* <div className="row">
                    <div className="col-sm-12">
                        <div className="card"> */}
        <Tabs
          defaultActiveKey="Determining"
          id="justify-tab-example"
          className="border-tab nav-primary pt-3 mb-3"
          justify
        >
          <Tab eventKey="Determining" title="Determining">
            <div className="row">
              <div className="col-sm-12">
                <div className="card">
                  <div className="card-header">
                    <h5>Determining My Legacy </h5>
                  </div>
                  <form className="form theme-form" onSubmit={handleSubmit}>
                    <div className="card-body m-3">
                      <div className="row">
                        <div className="col-sm-12">
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">How Do You What To Be Remembered After You Are Gone?</label>
                            <textarea
                              className="form-control"
                              name="winning"
                              rows="4"
                              required
                            ></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">How I Want To Be Remembered By My Spouse?</label>
                            <textarea className="form-control" rows="4" name="Spouse" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">How I want to be remembered by my children?</label>
                            <textarea className="form-control" rows="4" name="children" required></textarea>
                          </div>


                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">How I want to be remembered by my parents?</label>
                            <textarea className="form-control" rows="4" name="remembered" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">How I want to be remembered by my colleagues?</label>
                            <textarea className="form-control" rows="4" name="remembered" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">How I want to be remembered by my friends?</label>
                            <textarea className="form-control" rows="4" name="want" required></textarea>
                          </div>


                          <div className="card-footer">
                            <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                          </div>

                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </Tab>
          <Tab eventKey="Personal " title="Personal ">
            <div className="row">
              <div className="col-sm-12">
                <div className="card">
                  <div className="card-header">
                    <h5>Personal Legacy</h5>
                  </div>
                  <form className="form theme-form" onSubmit={handleSubmit}>
                    <div className="card-body m-3">
                      <div className="row">
                        <div className="col-sm-12">
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">Who Do I Want To Emulate In Life, Not Copy, But Who's Life Is A Good Representation Of Who Or What You Want To Be?</label>
                            <textarea
                              className="form-control"
                              name="winning"
                              rows="4"
                              required
                            ></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Are Some Experiences I Want To Have?</label>
                            <textarea className="form-control" rows="4" name="Experiences" required></textarea>
                          </div>

                          <div className="card-footer">
                            <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                          </div>

                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </Tab>
          <Tab eventKey="Family" title="Family">
            <div className="row">
              <div className="col-sm-12">
                <div className="card">
                  <div className="card-header">
                    <h5>Family Legacy</h5>
                  </div>

                  <form className="form theme-form" onSubmit={handleSubmit}>
                    <div className="card-body m-3">
                      <div className="row">
                        <div className="col-sm-12">
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Do I Value Most In My Family Relationships?</label>
                            <textarea
                              className="form-control"
                              name="winning"
                              rows="4"
                              required
                            ></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">How Do I Support Those Who Mean The Most To Me?</label>
                            <textarea className="form-control" name="Those" rows="4" required></textarea>
                          </div>

                          <div className="card-footer">
                            <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                          </div>

                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </Tab>
          <Tab eventKey="Work" title="work">
            <div className="row">
              <div className="col-sm-12">
                <div className="card">
                  <div className="card-header">
                    <h5>Work Legacy</h5>
                  </div>
                  <form className="form theme-form" onSubmit={handleSubmit}>
                    <div className="card-body m-3">
                      <div className="row">
                        <div className="col-sm-12">
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">How Can I Best Use My Skills To Impact The World?</label>
                            <textarea
                              className="form-control"
                              name="winning"
                              rows="4"
                              required
                            ></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Kind Of Work Do I Want To Contribute To?</label>
                            <textarea className="form-control" name="Work" rows="4" required></textarea>
                          </div>

                          <div className="card-footer">
                            <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                          </div>

                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </Tab>
          <Tab eventKey="Community" title="Community">
            <div className="row">
              <div className="col-sm-12">
                <div className="card">
                  <div className="card-header">
                    <h5>Community Legacy</h5>
                  </div>
                  <form className="form theme-form" onSubmit={handleSubmit}>
                    <div className="card-body m-3">
                      <div className="row">
                        <div className="col-sm-12">
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Communities Do I Want To Be Affiliated With?</label>
                            <textarea
                              className="form-control"
                              name="winning"
                              rows="4"
                              required
                            ></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Can I Do To Strengthen The Communities I'm Part Of?</label>
                            <textarea className="form-control" rows="4" name="Strengthen" required></textarea>
                          </div>

                          <div className="card-footer">
                            <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                          </div>

                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </Tab>

          <Tab eventKey="Mission " title="Mission ">
            <div className="row">
              <div className="col-sm-12">
                <div className="card">
                  <div className="card-header">
                    <h5>Mission and Purpose (answer at least one)</h5>
                  </div>
                  <form className="form theme-form" onSubmit={handleSubmit}>
                    <div className="card-body m-3">
                      <div className="row">
                        <div className="col-sm-12">
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Does My Community/Country Or World Most Need?</label>
                            <textarea
                              className="form-control"
                              name="winning"
                              rows="4"
                              required
                            ></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Makes Me Angry Or What Do I Care Strongly Enough About To Make Me Take Action? (Principles, Causes, Injustices, Etc.)</label>
                            <textarea className="form-control" rows="4" name="Angry" required ></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Personal Tragedy, Lllness, Or Loss Have I Experienced That Suggests How I Might Like To Serve Others?</label>
                            <textarea className="form-control" rows="4" name="Personal" required></textarea>
                          </div>


                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">I Have Not Yet Accomplished/Experienced Or Completed The Following Things In My Life...</label>
                            <textarea className="form-control" rows="4" name="Accomplished" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">Take A Look At Past Work, Career Choices - What Did You Like? What Did You Dislike?</label>
                            <textarea className="form-control" rows="4" name="Past" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Do People Ask You To Help Them With?</label>
                            <textarea className="form-control" rows="4" name="People" required></textarea>
                          </div>
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">  What Activities Really Bring Joy And Fulfillment In Your Life?</label>
                            <textarea className="form-control" rows="4" name="Activities" required></textarea>
                          </div>
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">Who Inspires You Most? Why?</label>
                            <textarea className="form-control" rows="4" name="Inspires" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Causes Do You Strongly Believe In And Connect With?</label>
                            <textarea className="form-control" rows="4" name="Causes" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Would You Do If... You Only Had One Year To Live?</label>
                            <textarea className="form-control" rows="4" name="Only" required></textarea>
                          </div>
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label"> What Would You Be Doing If You Had Unlimited Resources At Your Disposal?</label>
                            <textarea className="form-control" rows="4" name="Unlimited" required></textarea>
                          </div>
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">  Values & Purpose (Answer At Least One):
                              What Sustains Or Nourishes Me? What Gives Me Energy/"Juice"? Conversely, What Drains My Energy And Should Be Avoided?</label>
                            <textarea className="form-control" rows="4" name="Drains" required></textarea>
                          </div>
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Is Essential For My Life To Feel Worthwhile? What Are My Fundamental Beliefs And Values?</label>
                            <textarea className="form-control" rows="4" name="Essential" required></textarea>
                          </div>
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Experiences In My Life Have Really Made Me "Live"? What Themes And Patterns Emerge For Me?</label>
                            <textarea className="form-control" rows="4" name="Life" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Would Your Lifetime Achievements Be?</label>
                            <textarea className="form-control" rows="4" name="Lifetime" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Matters The Most At The End Of Your Life?</label>
                            <textarea className="form-control" rows="4" name="Matters" required></textarea>
                          </div>
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Will Be Your Legacy?</label>
                            <textarea className="form-control" rows="4" name="Legacy" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label"> What do you want to be remembered for?</label>
                            <textarea className="form-control" rows="4" name="want" required></textarea>
                          </div>
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Stories Will Friends And Loved Ones Share About You And Your Impact On Them?</label>
                            <textarea className="form-control" rows="4" name="Stories" required ></textarea>
                          </div>
                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">What Would I Want As My Epitaph Or My Eulogy?</label>
                            <textarea className="form-control" rows="4" name="Epitaph" required></textarea>
                          </div>

                          <div className="form-group row mb-2">
                            <label className="col-sm-12 col-form-label">How Would I Spend My Time If I Had No Financial Constraints And Could Not Fail? If I Had Six Months to Live? How About Three Years To Live?</label>
                            <textarea className="form-control" rows="4" name="Spend" required></textarea>
                          </div>
                          <div className="card-footer">
                            <button type="submit" className="btn btn-primary me-1 float-end">Submit</button>
                          </div>

                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </Tab>

        </Tabs>
        {/* </div >
                    </div >
                </div > */}
      </Container >
    </div>
  );

}

export default MyLegacy;
